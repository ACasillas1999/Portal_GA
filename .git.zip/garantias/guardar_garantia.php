<?php
// ===== JSON limpio =====
while (ob_get_level()) { ob_end_clean(); }
header('Content-Type: application/json; charset=UTF-8');
ini_set('display_errors','0'); error_reporting(E_ALL);
set_error_handler(function($lvl,$msg,$file,$line){ http_response_code(500); echo json_encode(['ok'=>false,'msg'=>"$msg ($file:$line)"]); exit; });
set_exception_handler(function($e){ http_response_code(500); echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); exit; });

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../app/db.php';
require_once __DIR__ . '/../app/WhatsBusiness.php'; // funciones WhatsApp

ini_set('session.cookie_httponly','1');
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS']==='off') ini_set('session.cookie_secure','0'); else ini_set('session.cookie_secure','1');
session_name('GA'); session_start();

function resp($ok,$a=[]){ echo json_encode(['ok'=>$ok]+$a); exit; }
function digits($s){ return preg_replace('/\D+/','',(string)$s); }

// Identidad
$uid = $_SESSION['user_id'] ?? $_SESSION['ID'] ?? $_SESSION['idUsuario'] ?? $_SESSION['usuario_id'] ?? null;

// POST
$email            = strtolower(trim($_POST['email'] ?? ''));
$telefono         = digits($_POST['telefono'] ?? '');
$producto         = trim($_POST['producto'] ?? '');
$no_serie         = trim($_POST['no_serie'] ?? '');
$codigo_factura   = trim($_POST['codigo_factura'] ?? '');
$no_factura       = trim($_POST['no_factura'] ?? '');
$fecha_factura    = trim($_POST['fecha_factura'] ?? '');
$marca            = trim($_POST['marca'] ?? '');
$sucursal         = trim($_POST['sucursal'] ?? '');
$descripcion      = trim($_POST['descripcion_falla'] ?? '');
$nombre_contacto  = trim($_POST['nombre_contacto'] ?? '');

$err=[];
if (!filter_var($email, FILTER_VALIDATE_EMAIL))           $err[]='Correo inválido';
if (!preg_match('/^\d{10}$/',$telefono))                  $err[]='Teléfono inválido (10 dígitos)';
if ($producto==='')                                       $err[]='Nombre del producto requerido';
if ($descripcion==='' || mb_strlen($descripcion)<5)       $err[]='Describe la falla con más detalle';
if ($nombre_contacto==='' || mb_strlen($nombre_contacto)<3)$err[]='Nombre de contacto requerido';
if ($fecha_factura!=='' && !preg_match('/^\d{4}-\d{2}-\d{2}$/',$fecha_factura)) $err[]='Fecha de factura inválida (YYYY-MM-DD)';
if ($err) resp(false,['msg'=>implode('. ',$err)]);

try{
  $pdo->beginTransaction();

  // Insert base con folio temporal
  $st = $pdo->prepare("
    INSERT INTO garantia_solicitudes
      (folio, id_usuario, email, telefono, producto, no_serie, codigo_factura, no_factura,
       fecha_factura, marca, sucursal, descripcion_falla, nombre_contacto, estado, created_at)
    VALUES
      ('TEMP', :uid, :email, :tel, :prod, :serie, :cod, :nfact, :ffact, :marca, :sucursal, :desc, :nomc, 'Recibida', NOW())
  ");
  $st->execute([
    ':uid'    => $uid,
    ':email'  => $email,
    ':tel'    => $telefono,
    ':prod'   => $producto,
    ':serie'  => $no_serie !== '' ? $no_serie : null,
    ':cod'    => $codigo_factura !== '' ? $codigo_factura : null,
    ':nfact'  => $no_factura !== '' ? $no_factura : null,
    ':ffact'  => $fecha_factura !== '' ? $fecha_factura : null,
    ':marca'  => $marca !== '' ? $marca : null,
    ':sucursal'=> $sucursal !== '' ? $sucursal : null,
    ':desc'   => $descripcion,
    ':nomc'   => $nombre_contacto,
  ]);
  $id = (int)$pdo->lastInsertId();

  // Folio definitivo GAR-YYYY-000001
  $folio = sprintf('GAR-%s-%06d', date('Y'), $id);
  $pdo->prepare("UPDATE garantia_solicitudes SET folio=? WHERE id=?")->execute([$folio,$id]);

  // Adjuntos
  if (!empty($_FILES['adjuntos']['name'][0])) {
    $baseDir = __DIR__ . '/uploads/' . date('Y/m');
    if (!is_dir($baseDir)) @mkdir($baseDir, 0775, true);
    $okExt = ['jpg','jpeg','png','gif','webp','mp4','mov','avi','mkv','webm','pdf','zip'];
    $f = $_FILES['adjuntos'];
    for ($i=0; $i<count($f['name']); $i++){
      if ($f['error'][$i] !== UPLOAD_ERR_OK) continue;
      if ($f['size'][$i] > 40*1024*1024) continue; // 40MB

      $ext = strtolower(pathinfo($f['name'][$i], PATHINFO_EXTENSION));
      if (!in_array($ext,$okExt,true)) continue;

      $safe = preg_replace('/[^a-z0-9\.\-\_]+/i','_', $f['name'][$i]);
      $dest = $baseDir . '/' . $id . '_' . uniqid('',true) . '_' . $safe;
      if (move_uploaded_file($f['tmp_name'][$i], $dest)) {
        $rel = 'uploads/' . date('Y/m') . '/' . basename($dest);
        $pdo->prepare("INSERT INTO garantia_adjuntos (id_solicitud, ruta, nombre_original, tamano) VALUES (?,?,?,?)")
            ->execute([$id, $rel, $f['name'][$i], (int)$f['size'][$i]]);
      }
    }
  }

  $pdo->commit();

  // ====== ENVÍO DE WHATSAPP A VENDEDORES (misma BD en la nube) ======
  try {
    if (trim($sucursal) === '') {
      file_put_contents(__DIR__.'/wa_new_garantia.log', date('c')." $folio: sucursal vacía, se omite WhatsApp\n", FILE_APPEND);
    } else {
      $tablaUsuarios = 'usuarios_cache'; // cambia si el nombre real es otro

      $q = $pdo->prepare("
          SELECT nombre_completo AS nombre, telefono AS tel
          FROM {$tablaUsuarios}
          WHERE UPPER(rol)='VENDEDOR'
            AND UPPER(sucursal)=UPPER(?)
            AND telefono IS NOT NULL AND telefono<>''");
      $q->execute([$sucursal]);
      $destinos = $q->fetchAll(PDO::FETCH_ASSOC);

      if (!$destinos) {
        file_put_contents(__DIR__.'/wa_new_garantia.log', date('c')." $folio: sin vendedores con teléfono en $sucursal\n", FILE_APPEND);
      } else {
        $plantilla = 'portal_nuevo_ga';
        $idioma    = 'en_US';

        foreach ($destinos as $usr) {
          $nombre = $usr['nombre'] ?: 'Vendedor';
          $telRaw = (string)($usr['tel'] ?? '');
          $digits = preg_replace('/\D+/', '', $telRaw);
          if ($digits === '' || strlen($digits) < 10) continue;

          $e164 = (strlen($digits) === 10) ? '+52'.$digits : '+'.$digits;

          $componentes = [[
            'type' => 'body',
            'parameters' => [
              ['type'=>'text','text'=> $nombre],
              ['type'=>'text','text'=> $folio],
              ['type'=>'text','text'=> $sucursal],
            ]
          ]];

          wa_send_template($e164, $plantilla, $componentes, $idioma);
          file_put_contents(__DIR__.'/wa_new_garantia.log', date('c')." $folio->$e164 [$nombre]\n", FILE_APPEND);
        }
      }
    }
  } catch (Throwable $e) {
    file_put_contents(__DIR__.'/wa_new_garantia.log', date('c')." ERROR $folio: ".$e->getMessage()."\n", FILE_APPEND);
  }

  // ← ahora sí respondemos al cliente
  resp(true,['folio'=>$folio]);

} catch(Throwable $e){
  if ($pdo->inTransaction()) $pdo->rollBack();
  resp(false,['msg'=>$e->getMessage()]);
}
